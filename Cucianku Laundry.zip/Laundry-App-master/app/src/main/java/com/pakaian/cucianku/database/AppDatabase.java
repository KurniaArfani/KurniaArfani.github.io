package com.pakaian.cucianku.database;

import androidx.room.Database;
import androidx.room.RoomDatabase;

import com.pakaian.cucianku.database.dao.LaundryDao;
import com.pakaian.cucianku.model.ModelLaundry;

@Database(entities = {ModelLaundry.class}, version = 1)
public abstract class AppDatabase extends RoomDatabase {
    public abstract LaundryDao laundryDao();
}
